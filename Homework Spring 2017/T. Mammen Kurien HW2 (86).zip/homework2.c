#include <unistd.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main()
{
clock_t start = clock();
//**********Getting a userid**********
char *buf;								//Creates a new String named buf
buf=(char *)malloc(100*sizeof(char));	//increases the memory allocated to buf
printf("User Id: %s\n",cuserid(buf));

//**********Getting a working directory**********
char *direct;
direct=(char *)malloc(100*sizeof(char));
printf("Working Directory: %s\n",getcwd(direct,100));

//**********Getting a hostname**********
char hostname[128];
gethostname(hostname,6);
printf("Parent Hostname = %s\n", hostname);

//**********Getting the current time**********
time_t currtime;
time(&currtime);
printf("Current time is %s",ctime(&currtime));

//**********Getting the pid**********
pid_t pid;
printf("Hello this is the parent Hippopotamus, my pid is: %d \n", getpid());
//sleep(3);
if(putenv("HIPPO=11") != 0)
 {
    printf("Hey I executed this line, still no hippo? :( \n");
 }
 sleep(3);
									//**********Child 1 Process here**********
pid = fork();
if (!pid)
	{	
		//sleep(2);
		printf("Hello, I am the first child; pid: %d, ppid: %d \n\n", getpid(), getppid());
		printf("First Child: real user id: %d. effective user id: %d. real group id: %d. effective group id: %d.\n", getuid(), geteuid(), getgid(), getegid());	
		fflush(stdout);
		sleep(2);
		HippoMinus(); //10
		HippoMinus(); //9
		printf("C1: %s \n", getenv("HIPPO"));
		sleep(3);
		HippoMinus(); //8
		HippoMinus(); //7
		HippoMinus(); //6
		printf("C1: %s \n", getenv("HIPPO"));
		sleep(3);
		HippoMinus(); //5
		HippoMinus(); //4
		HippoMinus(); //3
		printf("C1: %s \n", getenv("HIPPO"));
		sleep(2);
		HippoMinus(); //2
		HippoMinus(); //1
		printf("Working Directory: %s\n",getcwd(direct,100));
		HippoPlus();
		printf("Final Hippo Value After Incrementing : %s \n", getenv("HIPPO"));
		clock_t end = clock();
		double totaltime = (double)(start - end) / CLOCKS_PER_SEC;
		printf("Child One: CPU time: %fs\n", totaltime);
		exit(0);
		return 0;
	}

									//**********Child 2 Process here**********
pid = fork();
if(!pid)
	{
		//sleep(1);
		printf("Hello, I am the second child. pid: %d, ppid: %d\n \n", getpid(), getppid());
		printf("Second Child: real user id: %d. effective user id: %d. real group id: %d. effective group id: %d.\n", getuid(), geteuid(), getgid(), getegid());
		fflush(stdout);
		sleep(3);
		HippoMinus(); //10
		HippoMinus(); //9
		HippoMinus(); //8
		printf("C2: %s \n", getenv("HIPPO"));
		sleep(3);
		HippoMinus(); //7
		HippoMinus(); //6
		HippoMinus(); //5
		printf("C2: %s \n", getenv("HIPPO"));
		sleep(3);
		HippoMinus(); //4
		HippoMinus(); //3
		HippoMinus(); //2
		printf("C2: %s \n", getenv("HIPPO"));
		sleep(1);
		HippoMinus(); //1
		chdir("/assignments/");
        char* changes[] = {"ls",NULL};
		clock_t end = clock();
		double totaltime = (double)(start - end) / CLOCKS_PER_SEC;
		printf("Child Two: CPU time: %fs\n", totaltime);
		execv("ls", changes);
		return 0;
	}		


									//*******Parent Processes Start Here:*******\\
		sleep(3);
		HippoMinus(); //10
		sleep(1);
		printf("P10: %s \n", getenv("HIPPO"));
		sleep(4);
		HippoMinus(); //9
		HippoMinus(); //8
		HippoMinus(); //7
		printf("P: %s \n", getenv("HIPPO"));
		sleep(3);
		HippoMinus(); //6
		HippoMinus(); //5
		HippoMinus(); //4
		printf("P: %s \n", getenv("HIPPO"));
		sleep(4);
		HippoMinus(); //3
		HippoMinus(); //2
		HippoMinus(); //1
		printf("P: %s \n", getenv("HIPPO"));
		wait();
		wait();
		clock_t end = clock();
		double totaltime = (double)(start - end) / CLOCKS_PER_SEC;
		printf("Parent Process: CPU time: %fs\n", totaltime);
		return 0;
}

int HippoMinus()
{
        int temp = atoi(getenv("HIPPO"));
        char buffer[10];
        sprintf(buffer, "%d", temp - 1);
        setenv("HIPPO", buffer, 1);
}

int HippoPlus()
{
	int incr = atoi(getenv("HIPPO"));
	char adder[10];
    sprintf(adder, "%d", incr + 1);
    setenv("HIPPO", adder, 1);
}


