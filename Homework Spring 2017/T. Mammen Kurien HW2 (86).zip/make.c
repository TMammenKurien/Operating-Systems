homework2: homework2.c
	gcc -o hw2 homework2.c