#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
#include <stdlib.h>


#define SEMAPHORE_KEY        0xF1A5

//Semaphore definitions
#define MUTEX	    	0
#define ATOB	 		1
#define BTOA  			2
#define NUMBER_SEMS		3

//Baboon directions
#define BaboonAtoB		1
#define BaboonBtoA		2

//Waiting semaphore function
int sem_wait(int semid, ushort semnum);

//Signalling semaphore function
int sem_signal(int semid, ushort semnum);


//Getting the semaphore id
int get_semid(key_t semkey);


void baboon_fork(int Cross_Direction)
;

//Getting the shared memory id
int get_shmid(key_t shmkey)
{
    int value = shmget(shmkey, 5, 0777 | IPC_CREAT);
    if (value == -1)
    {
        perror("shmget failed");
        exit(EXIT_FAILURE);
    }
    return value;
}

union semun
{
    int              val;    /* Value for SETVAL */
    struct semid_ds *buf;    /* Buffer for IPC_STAT, IPC_SET */
    unsigned short  *array;  /* Array for GETALL, SETALL */
    //No 4th argument
};


struct shared_variable_struct
{
    int XingCount;
    int XedCount;
    int ToBWaitCount;
    int ToAWaitCount;
    enum {None, AtoB, BtoA} XingDirection;
};



//variables to change
// get_semid; semaphores_values; get_shmid; shared_variables

int main(int argc, char *argv[])
{

    //Values for semaphore creation
    union semun semaphore_values;
    unsigned short temp_array[3] = {1, 0, 0};
    semaphore_values.array = temp_array;

    //Create the semaphore, use semctl
    int semid = get_semid((key_t) SEMAPHORE_KEY);
    if (semctl(semid, MUTEX, SETALL, semaphore_values) == -1)
    {
        perror("semctl failed");
        exit(EXIT_FAILURE);
    }

    //Get the shared memory Id
    int shmid = get_shmid((key_t)SEMAPHORE_KEY);

    //Attaches shared memory segment identified by shmid to the address space shared variables
    struct shared_variable_struct * shared_variables = shmat(shmid, 0, 0);

    //Initial values of each shared variabled in shared memory is being set.
    shared_variables->XingCount = 0;
    shared_variables->XedCount = 0;
    shared_variables->ToAWaitCount = 0;
    shared_variables->ToBWaitCount = 0;
    shared_variables->XingDirection = None;

    //DON'T FORGET BIG LOOP HERE
    int i = 0;
    while(argv[1][i] != 0)
    {
        switch (argv[1][i])
        {
            case 'a':
            case 'A':
                baboon_fork(BaboonAtoB);
                break;

            case 'b':
            case 'B':
                baboon_fork(BaboonBtoA);
                break;

            default:
                printf("!!! PID: %d: Invalid argument: `%c`! The only valid arguments are 'w', 'W', 'e', and 'E'.\n", getpid(), argv[1][i]);
                exit(EXIT_FAILURE);
                break;

        }
        usleep(7000);
        i++;
    }

    int j;
    for (j = 0; j < i; j++)
    {
        wait(NULL);
    }

    //Detaches shared memory segment
    if (shmdt(shared_variables) == -1)
    {
        perror("shmdt failed");
        exit(EXIT_FAILURE);
    }

    //Marks the shared memory segment for deletion
    if (shmctl(shmid, IPC_RMID, NULL) < 0)
    {
        perror("shmctrl failed");
        exit(EXIT_FAILURE);
    }

    //Marks the semaphore set for deletion.
    if (semctl(semid, MUTEX, IPC_RMID, semaphore_values) == -1)
    {
        perror("semctl failed");
        exit(EXIT_FAILURE);
    }

    //Main ends
}

void AtoBfunc()
{
    printf("A to B: Baboon %d gets to the rope, he's ready to cross!!\n", getpid());

    //Load Semaphore set
    int semid = get_semid((key_t)SEMAPHORE_KEY);
    //Load shared memory
    int shmid = get_shmid((key_t)SEMAPHORE_KEY);
    struct shared_variable_struct * shared_variables = shmat(shmid, 0, 0);
    sem_wait(semid, MUTEX);
    if((shared_variables->XingDirection == AtoB) || (shared_variables->XingDirection == None)
                                                    && (shared_variables->XingCount < 5) && (shared_variables->XedCount + shared_variables->XingCount < 10))
    {
        shared_variables -> XingDirection = AtoB;
        shared_variables -> XingCount++;
        sem_signal(semid, MUTEX);
    }
    else
    {
        shared_variables -> ToBWaitCount++;
        sem_signal(semid, MUTEX);
        sem_wait(semid, ATOB);
        shared_variables -> ToBWaitCount--;
        shared_variables -> XingCount++;
        shared_variables -> XingDirection = AtoB;
        sem_signal(semid, MUTEX);
    }
    printf("Baboon %d started crossing the rope from A\n", getpid());
    sem_wait(semid, MUTEX);
    usleep(100000);
    printf("Baboon %d finished crossing the rope from A\n", getpid());
    shared_variables -> XedCount++;
    shared_variables -> XingCount--;
    if (shared_variables -> ToBWaitCount != 0 && (((shared_variables -> XingCount + shared_variables -> XedCount) < 10)
                                                  ||((shared_variables -> XedCount + shared_variables -> XingCount) >= 10 && shared_variables -> ToAWaitCount == 0)))
    {
        sem_signal(semid, ATOB);
    }
    else if (shared_variables ->  XingCount == 0 && shared_variables -> ToAWaitCount != 0
             &&(shared_variables -> ToBWaitCount == 0 || (shared_variables -> XedCount + shared_variables -> XingCount) >= 10))
    {
        shared_variables -> XingDirection = BtoA;
        shared_variables -> XedCount = 0;
        sem_signal(semid, BTOA);
    }
    else if (shared_variables -> XingCount == 0 && shared_variables -> ToBWaitCount == 0 && shared_variables -> ToAWaitCount == 0)
    {
        shared_variables -> XingDirection = None;
        shared_variables -> XedCount = 0;
        sem_signal(semid, MUTEX);
    }
    else
    {
        sem_signal(semid, MUTEX);
    }

    exit(EXIT_SUCCESS);
}

void BtoAfunc()
{
    printf("B to A: Baboon %d gets to the rope, he's ready to cross!!\n", getpid());

    //Load Semaphore set
    int semid = get_semid((key_t)SEMAPHORE_KEY);
    //Load shared memory
    int shmid = get_shmid((key_t)SEMAPHORE_KEY);
    struct shared_variable_struct * shared_variables = shmat(shmid, 0, 0);
    sem_wait(semid, MUTEX);
    if((shared_variables->XingDirection == BtoA) || (shared_variables->XingDirection == None)
                                                    && (shared_variables->XingCount < 5) && (shared_variables->XedCount + shared_variables->XingCount < 10))
    {
        shared_variables -> XingDirection = BtoA;
        shared_variables -> XingCount++;
        sem_signal(semid, MUTEX);
    }
    else
    {
        shared_variables -> ToAWaitCount++;
        sem_signal(semid, MUTEX);
        sem_wait(semid, BTOA);
        shared_variables -> ToAWaitCount--;
        shared_variables -> XingCount++;
        shared_variables -> XingDirection = BtoA;
        sem_signal(semid, MUTEX);
    }
    printf("Baboon %d started crossing the rope from B\n", getpid());
    sem_wait(semid, MUTEX);
    usleep(100000);
    printf("Baboon %d finished crossing the rope from B\n", getpid());
    shared_variables -> XedCount++;
    shared_variables -> XingCount--;
    if (shared_variables -> ToAWaitCount != 0 && (((shared_variables -> XingCount + shared_variables -> XedCount) < 10)
                                                  ||((shared_variables -> XedCount + shared_variables -> XingCount) >= 10 && shared_variables -> ToBWaitCount == 0)))
    {
        sem_signal(semid, BTOA);
    }
    else if ((shared_variables ->  XingCount == 0 && shared_variables -> ToBWaitCount != 0)
             &&((shared_variables -> ToAWaitCount == 0)
                || (shared_variables -> XedCount + shared_variables -> XingCount) >= 10))
    {
        shared_variables -> XingDirection = AtoB;
        shared_variables -> XedCount = 0;
        sem_signal(semid, ATOB);
    }
    else if (shared_variables -> XingCount == 0 && shared_variables -> ToAWaitCount == 0 && shared_variables -> ToBWaitCount == 0)
    {
        shared_variables -> XingDirection = None;
        shared_variables -> XedCount = 0;
        sem_signal(semid, MUTEX);
    }
    else
    {
        sem_signal(semid, MUTEX);
    }

    exit(EXIT_SUCCESS);
}

void baboon_fork(int Cross_Direction)
{
    pid_t pid;
    pid = fork();
    if (pid == -1)
    {
        perror("Fork failure");
        exit(EXIT_FAILURE);
    }
    else if (pid == 0)
    {
        if (Cross_Direction == BaboonAtoB)
        {
            AtoBfunc();
        }
        else if (Cross_Direction == BaboonBtoA)
        {
            BtoAfunc();
        }
        else
        {
            perror("Invalid input.  Bad char type");
            exit(EXIT_FAILURE);
        }
    }
}

int sem_signal(int semid, ushort semnum)
{
    static struct sembuf signal_buf = {0, 1, 0};
    signal_buf.sem_num = semnum;
    return semop(semid, &signal_buf, 1);
}

int sem_wait(int semid, ushort semnum)
{
    static struct sembuf wait_buf = {0, -1, 0};
    wait_buf.sem_num = semnum;
    return semop(semid, &wait_buf, 1);
}

int get_semid(key_t semkey)
{
    int id_temp = semget(semkey, NUMBER_SEMS, 0777 | IPC_CREAT);
    if (id_temp == -1)
    {
        perror("semget FAILED. SAD. FAKE NEWS");
        exit(EXIT_FAILURE);
    }
    return id_temp;
}