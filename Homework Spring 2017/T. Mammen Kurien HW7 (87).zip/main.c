#include <sys/types.h>
#include <sys/shm.h>
#include <unistd.h>
#include <semaphore.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>

#define SEMAPHORE_KEY        0xFD47

#define wait1 7000
#define wait2 100000

//struct to pass an empty param to thread_t
typedef struct thread_data_t
{ }
thread_data_t;

//pointers to methods
void *AtoBfunc(void *args);
void *BtoAfunc(void *args);

//Semaphore definition
sem_t MUTEX;
sem_t babsAtoB;
sem_t babsBtoA;

int get_shmid(key_t shmkey);

//Getting the shared memory id
int get_shmid(key_t shmkey)
{
int value = shmget(shmkey, 5, 0777 | IPC_CREAT);
	if (value == -1)
	{
		perror("shmget failed");
		exit(EXIT_FAILURE);
	}
	return value;
}

struct shared_variable_struct
{
	int XingCount;
	int XedCount;
	int ToBWaitCount;
	int ToAWaitCount;
	enum {None, AtoB, BtoA} XingDirection;
};


int main(int argc, char *argv[])
{
	if(argv[1] == NULL)
	{
        perror("Input an argument");
    }

	sem_init(&MUTEX, 0, (unsigned int)1);
	sem_init(&babsAtoB, 0, (unsigned int)0);
	sem_init(&babsBtoA, 0, (unsigned int)0);

	void* status;
	int shmid = get_shmid((key_t)SEMAPHORE_KEY);

	//Attaches shared memory segment identified by shmid to the address space shared variables
	struct shared_variable_struct * shared_variables = shmat(shmid, 0, 0);

	//Initial values of each shared variabled in shared memory is being set.
	shared_variables->XingCount = 0;
	shared_variables->XedCount = 0;
	shared_variables->ToAWaitCount = 0;
	shared_variables->ToBWaitCount = 0;
	shared_variables->XingDirection = None;

	//DON'T FORGET BIG LOOP HERE
	int i = 0;
	pthread_t pthreads[sizeof(argv[1])+1];
	while(argv[1][i] != 0)
	{
		switch (argv[1][i])
			{
			case 'a':
			case 'A':
				pthread_create(&pthreads[i], NULL, AtoBfunc, NULL);
				break;

			case 'b':
			case 'B':
				pthread_create(&pthreads[i], NULL, BtoAfunc, NULL);
				break;

			default:
				printf("Invalid arguments. FAILURE.");
				exit(EXIT_FAILURE);
				break;

		}
        i++;
        
	}

	int j;
	for (j = 0; j < i; j++)
	{
		pthread_join(pthreads[j], &status);
	}

	//Detaches shared memory segment
	if (shmdt(shared_variables) == -1)
	{
		perror("shmdt failed");
		exit(EXIT_FAILURE);
	}

	//Marks the shared memory segment for deletion
	if (shmctl(shmid, IPC_RMID, NULL) < 0)
	{
		perror("shmctrl failed");
		exit(EXIT_FAILURE);
	}
	//Main ends
	exit(0);
}

void *AtoBfunc(void *args)
{
	printf("A to B: Baboon %d gets to the rope, he's ready to cross!!\n", getpid());
	int shmid = get_shmid((key_t)SEMAPHORE_KEY);
	struct shared_variable_struct * shared_variables = shmat(shmid, 0, 0);
	sem_wait(&MUTEX);
	if((shared_variables->XingDirection == AtoB) || (shared_variables->XingDirection == None)
		&& (shared_variables->XingCount < 5) && (shared_variables->XedCount + shared_variables->XingCount < 10))
	{
	    shared_variables -> XingDirection = AtoB;
        shared_variables -> XingCount++;
        sem_post(&MUTEX);
	}
	else
	{
		shared_variables -> ToBWaitCount++;
        sem_post(&MUTEX);
        sem_wait(&babsAtoB);
        shared_variables -> ToBWaitCount--;
        shared_variables -> XingCount++;
        shared_variables -> XingDirection = AtoB;
        sem_post(&MUTEX);
	}
	printf("Baboon %d started crossing the rope from A\n", getpid());
	//usleep(wait2);
    printf("Baboon %d finished crossing the rope from A\n", getpid());
    sem_wait(&MUTEX);
    shared_variables -> XedCount++;
    shared_variables -> XingCount--;
    if (shared_variables->ToBWaitCount != 0 && (((shared_variables->XingCount + shared_variables->XedCount) < 10) ||
                                           ((shared_variables->XedCount + shared_variables->XingCount) >= 10 &&
                                            shared_variables->ToAWaitCount == 0)))
    {
    	sem_post(&babsAtoB);
    }
    else if (shared_variables->XingCount == 0 && shared_variables->ToAWaitCount != 0 && (shared_variables->ToBWaitCount == 0
                                                                                 || (shared_variables->XedCount +
                                                                                     shared_variables->XingCount) >= 10))
    {
    	shared_variables -> XingDirection = BtoA;
        shared_variables -> XedCount = 0;
        sem_post(&babsBtoA);
    }
    else if (shared_variables->XingCount == 0 && shared_variables->ToBWaitCount == 0 && shared_variables->ToAWaitCount == 0)
    {
    	shared_variables -> XingDirection = None;
        shared_variables -> XedCount = 0;
        sem_post(&MUTEX);
    }
    else
    {
    	sem_post(&MUTEX);
    }

    pthread_exit(NULL);
}

void *BtoAfunc(void *args)
{
	printf("B to A: Baboon %d gets to the rope, he's ready to cross!!\n", getpid());
	//Load shared memory
	int shmid = get_shmid((key_t)SEMAPHORE_KEY);
	struct shared_variable_struct * shared_variables = shmat(shmid, 0, 0);
	sem_wait(&MUTEX);
	if((shared_variables->XingDirection == BtoA || shared_variables->XingDirection == None) &&
        shared_variables->XingCount < 5 && (shared_variables->XedCount + shared_variables->XingCount < 10))
	{
	    shared_variables -> XingDirection = BtoA;
        shared_variables -> XingCount++;
        sem_post(&MUTEX);
	}
	else
	{
		shared_variables -> ToAWaitCount++;
        sem_post(&MUTEX);
        sem_wait(&babsBtoA);
        shared_variables -> ToAWaitCount--;
        shared_variables -> XingCount++;
        shared_variables -> XingDirection = BtoA;
        sem_post(&MUTEX);
	}

	printf("Baboon %d started crossing the rope from B\n", getpid());
    sem_wait(&MUTEX);
    printf("Baboon %d finished crossing the rope from B\n", getpid());
    shared_variables -> XedCount++;
    shared_variables -> XingCount--;
    if (shared_variables->ToAWaitCount != 0 && (((shared_variables->XingCount + shared_variables->XedCount) < 10) ||
                                           ((shared_variables->XedCount + shared_variables->XingCount) >= 10 &&
                                            shared_variables->ToBWaitCount == 0)))
    {
    	sem_post(&babsBtoA);
    }
    else if (shared_variables->XingCount == 0 && shared_variables->ToBWaitCount != 0 && (shared_variables->ToAWaitCount == 0
                                                                                 || (shared_variables->XedCount +
                                                                                     shared_variables->XingCount) >= 10))
    {
    	shared_variables -> XingDirection = AtoB;
        shared_variables -> XedCount = 0;
        sem_post(&babsAtoB);
    }
    else if (shared_variables->XingCount == 0 && shared_variables->ToAWaitCount == 0 && shared_variables->ToBWaitCount == 0)
    {
    	shared_variables -> XingDirection = None;
        shared_variables -> XedCount = 0;
        sem_post(&MUTEX);
    }
    else
    {
    	sem_post(&MUTEX);
    }

  pthread_exit(NULL);
}






