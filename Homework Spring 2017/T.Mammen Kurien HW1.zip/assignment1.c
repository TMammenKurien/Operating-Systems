#include <stdio.h>
int main(){
int terms, i;
printf("Enter number of terms needed \n");
scanf("%d", &terms);
printf("Fibonacci series till %d terms \n ", terms);
for(i = 0; i < terms; i++){
printf("%d\n", fib(i));
}
return 0;
}

int fib(int terms)
{
if(terms < 2)
return terms;
return fib(terms - 1) + fib(terms - 2);
}





























